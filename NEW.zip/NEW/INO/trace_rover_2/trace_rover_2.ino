#include <WiFi.h>
#include <WiFiUdp.h>
#include <esp_wifi.h>
#include <Wire.h>
#include <DHT.h>

// ============================================================
// WI-FI & UDP CONFIGURATION (ROVER 2 - CONNECTS TO ROVER 1 AP)
// ============================================================
const char* AP_SSID = "TRACE_ROBOT"; // Rover 1 AP SSID
const char* AP_PASS = "12345678";    // Rover 1 AP Password

const char* ROVER1_AP_IP   = "192.168.4.1";
const char* BROADCAST_IP   = "192.168.4.255";
const int   TELEMETRY_PORT = 5005; // Port software listens on
const int   COMMAND_PORT   = 5006; // Port for arrow key commands
const int   RELAY_PORT     = 5007; // Rover 1 AP relay port

WiFiUDP udpTelemetry;
WiFiUDP udpCommand;

unsigned long lastTelemetryMs = 0;
unsigned long lastDhtMs       = 0;
unsigned long lastDebugMs     = 0;

float cachedTemp = 0.0;
float cachedHum  = 0.0;

// ============================================================
// GPIO PIN DEFINITIONS
// ============================================================
#define MQ2_PIN       0
#define TRIG1_PIN     1
#define ECHO1_PIN     2
#define DHT_PIN       3
#define DHT_TYPE      DHT11   // Set to DHT22 if using a white sensor
#define TRIG2_PIN     4
#define ECHO2_PIN     5
#define TRIG3_PIN     6
#define ECHO3_PIN     7
#define SDA_PIN       8
#define SCL_PIN       9
#define MOTOR1_PIN    20
#define MOTOR2_PIN    21

// ============================================================
// MPU REGISTERS
// ============================================================
#define IMU_ADDR      0x68
#define PWR_MGMT_1    0x6B
#define ACCEL_CONFIG  0x1C
#define GYRO_CONFIG   0x1B
#define ACCEL_XOUT_H  0x3B

DHT dht(DHT_PIN, DHT_TYPE);

// ============================================================
// I2C & SENSOR HELPERS
// ============================================================
void writeRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(IMU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

void readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length) {
  Wire.beginTransmission(IMU_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom(IMU_ADDR, length);
  for (uint8_t i = 0; i < length; i++) {
    buffer[i] = Wire.available() ? Wire.read() : 0;
  }
}

int16_t makeInt16(uint8_t highByte, uint8_t lowByte) {
  return (int16_t)((highByte << 8) | lowByte);
}

float getDistance(uint8_t trigPin, uint8_t echoPin) {
  // If a cheap HC-SR04 module has latched ECHO HIGH, briefly clear it
  if (digitalRead(echoPin) == HIGH) {
    pinMode(echoPin, OUTPUT);
    digitalWrite(echoPin, LOW);
    delayMicroseconds(50);
    pinMode(echoPin, INPUT);
    delayMicroseconds(50);
  }

  digitalWrite(trigPin, LOW);
  delayMicroseconds(4);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(12);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 25000); // 25ms timeout (~4.2m)
  if (duration <= 0) return -1.0;
  return (duration * 0.0343f) / 2.0f;
}

void setMotors(bool m1, bool m2) {
  digitalWrite(MOTOR1_PIN, m1 ? HIGH : LOW);
  digitalWrite(MOTOR2_PIN, m2 ? HIGH : LOW);
}

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);

  // 1. Motor Pins (Default OFF)
  pinMode(MOTOR1_PIN, OUTPUT);
  pinMode(MOTOR2_PIN, OUTPUT);
  setMotors(false, false);

  // 2. Ultrasonic Pins
  pinMode(TRIG1_PIN, OUTPUT);
  digitalWrite(TRIG1_PIN, LOW);
  pinMode(ECHO1_PIN, INPUT);

  pinMode(TRIG2_PIN, OUTPUT);
  digitalWrite(TRIG2_PIN, LOW);
  pinMode(ECHO2_PIN, INPUT);

  pinMode(TRIG3_PIN, OUTPUT);
  digitalWrite(TRIG3_PIN, LOW);
  pinMode(ECHO3_PIN, INPUT);

  // 3. Sensor Pins
  pinMode(MQ2_PIN, INPUT);
  dht.begin();

  // 4. IMU Bus Initialization
  Wire.begin(SDA_PIN, SCL_PIN);
  delay(50);
  writeRegister(PWR_MGMT_1, 0x00);
  delay(20);
  writeRegister(ACCEL_CONFIG, 0x00);
  writeRegister(GYRO_CONFIG, 0x00);

  // 5. Connect to Rover 1 AP (ESP32-C3 stable 8.5dBm configuration)
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(100);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  esp_wifi_set_max_tx_power(WIFI_POWER_8_5dBm);

  WiFi.begin(AP_SSID, AP_PASS);
  esp_wifi_set_max_tx_power(WIFI_POWER_8_5dBm); // Re-apply after WiFi.begin()

  Serial.println("\nConnecting to Rover 1 Access Point (TRACE_ROBOT)...");
  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startAttempt < 10000)) {
    delay(300);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nCONNECTED TO ROVER 1 AP!");
    Serial.print("Rover 2 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.printf("\nStill connecting in background (status=%d)...\n", WiFi.status());
  }

  // 6. Open Command Port for Arrow Key Control
  udpCommand.begin(COMMAND_PORT);
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  unsigned long now = millis();

  // 1. Listen for Manual Arrow Key Commands
  int packetSize = udpCommand.parsePacket();
  if (packetSize) {
    char cmd = udpCommand.read();
    if (cmd == '2' && udpCommand.available()) {
      cmd = udpCommand.read();
    }
    if (cmd == 'F') {        // Forward
      setMotors(true, true);
    } else if (cmd == 'L') { // Left Turn
      setMotors(false, true);
    } else if (cmd == 'R') { // Right Turn
      setMotors(true, false);
    } else if (cmd == 'S') { // Stop
      setMotors(false, false);
    }
    while (udpCommand.available()) {
      udpCommand.read();
    }
  }

  // 2. Read Slow DHT11 Every 2000ms (avoids blocking ultrasonic pulseIn every 60ms)
  if (now - lastDhtMs >= 2000) {
    lastDhtMs = now;
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    if (!isnan(t)) cachedTemp = t;
    if (!isnan(h)) cachedHum  = h;
  }

  // 3. Send Telemetry Packet Every 60ms (~16 Hz)
  if (now - lastTelemetryMs >= 60) {
    lastTelemetryMs = now;

    // Read MPU6050
    uint8_t buffer[14];
    readRegisters(ACCEL_XOUT_H, buffer, 14);
    int16_t ax = makeInt16(buffer[0], buffer[1]);
    int16_t ay = makeInt16(buffer[2], buffer[3]);
    int16_t az = makeInt16(buffer[4], buffer[5]);
    int16_t gx = makeInt16(buffer[8], buffer[9]);
    int16_t gy = makeInt16(buffer[10], buffer[11]);
    int16_t gz = makeInt16(buffer[12], buffer[13]);

    // Read Ultrasonics with brief acoustic settling delay between sensors
    float dist1 = getDistance(TRIG1_PIN, ECHO1_PIN);
    delayMicroseconds(1000);
    float dist2 = getDistance(TRIG2_PIN, ECHO2_PIN);
    delayMicroseconds(1000);
    float dist3 = getDistance(TRIG3_PIN, ECHO3_PIN);

    // Read MQ2
    int mq2Val = analogRead(MQ2_PIN);

    // Print ultrasonic readings every 500ms on Serial Monitor for quick hardware check
    if (now - lastDebugMs >= 500) {
      lastDebugMs = now;
      Serial.printf("R2 Sonar -> d1: %.1f cm | d2: %.1f cm | d3: %.1f cm\n", dist1, dist2, dist3);
    }

    // Build JSON (Explicitly tagged as Rover 2)
    String payload = "{";
    payload += "\"rover\":2,";
    payload += "\"ax\":" + String(ax) + ",";
    payload += "\"ay\":" + String(ay) + ",";
    payload += "\"az\":" + String(az) + ",";
    payload += "\"gx\":" + String(gx) + ",";
    payload += "\"gy\":" + String(gy) + ",";
    payload += "\"gz\":" + String(gz) + ",";
    payload += "\"mq2\":" + String(mq2Val) + ",";
    payload += "\"d1\":" + String(dist1, 1) + ",";
    payload += "\"d2\":" + String(dist2, 1) + ",";
    payload += "\"d3\":" + String(dist3, 1) + ",";
    payload += "\"temp\":" + String(cachedTemp, 1) + ",";
    payload += "\"hum\":" + String(cachedHum, 1);
    payload += "}";

    if (WiFi.status() == WL_CONNECTED) {
      // 1. Send to Rover 1 AP Relay (192.168.4.1:5007) so Rover 1 broadcasts it to Laptop
      udpTelemetry.beginPacket(ROVER1_AP_IP, RELAY_PORT);
      udpTelemetry.write((const uint8_t*)payload.c_str(), payload.length());
      udpTelemetry.endPacket();

      // 2. Also broadcast directly on subnet (192.168.4.255:5005)
      udpTelemetry.beginPacket(BROADCAST_IP, TELEMETRY_PORT);
      udpTelemetry.write((const uint8_t*)payload.c_str(), payload.length());
      udpTelemetry.endPacket();
    }
  }
}
