#include <Arduino.h>
#include "esp_camera.h"
#include "img_converters.h"
#include <WiFi.h>
#include <WiFiUdp.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <esp_wifi.h>

// =====================================================
// CAMERA IDENTITY: CAMERA 1 (ROVER 1)
// =====================================================
#define CAM_ID 1
static const char* MDNS_HOSTNAME = "trace-cam1";

// ================= WIFI SETTINGS =================
static const char* WIFI_SSID = "TRACE_ROBOT";
static const char* WIFI_PASS = "12345678";

// Static IP outside Rover 1's initial DHCP range (.2 / .3) to avoid IP conflict
IPAddress cameraIP(192, 168, 4, 11);
IPAddress gateway(192, 168, 4, 1);
IPAddress subnet(255, 255, 255, 0);

static const unsigned int UDP_PORT = 5005;
WiFiUDP udp;
unsigned long lastAnnounceMs = 0;

static uint8_t jpegQuality = 70;

// ================= CAMERA PIN MAP =================
// AI-Thinker-style ESP32-CAM
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

WebServer server(80);

// ================= UDP CAMERA DISCOVERY =================
void announceCamera() {
  if (WiFi.status() != WL_CONNECTED) return;
  unsigned long now = millis();
  if (now - lastAnnounceMs < 2000) return;
  lastAnnounceMs = now;

  String ipStr = WiFi.localIP().toString();
  char payload[160];
  snprintf(
    payload, sizeof(payload),
    "{\"type\":\"cam\",\"cam_id\":%d,\"ip\":\"%s\",\"stream\":\"http://%s/stream\",\"capture\":\"http://%s/capture\"}",
    CAM_ID, ipStr.c_str(), ipStr.c_str(), ipStr.c_str()
  );

  udp.beginPacket(IPAddress(192, 168, 4, 255), UDP_PORT);
  udp.print(payload);
  udp.endPacket();
}

// ================= CAMERA INITIALIZATION =================
bool initCamera() {
  camera_config_t config = {};

  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;

  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;

  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;

  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;

  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;

  // Proven RGB565 pipeline with low-latency frame grabbing & DRAM fallback
  config.xclk_freq_hz = 10000000;
  config.pixel_format = PIXFORMAT_RGB565;
  config.frame_size = FRAMESIZE_QQVGA;
  if (psramFound()) {
    config.fb_count = 2;
    config.grab_mode = CAMERA_GRAB_LATEST;
    config.fb_location = CAMERA_FB_IN_PSRAM;
  } else {
    config.fb_count = 1;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    config.fb_location = CAMERA_FB_IN_DRAM;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    // Fallback to single DRAM buffer if PSRAM allocation failed
    config.fb_count = 1;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    config.fb_location = CAMERA_FB_IN_DRAM;
    err = esp_camera_init(&config);
    if (err != ESP_OK) {
      Serial.printf("Camera init failed: 0x%02X\n", err);
      return false;
    }
  }

  sensor_t* sensor = esp_camera_sensor_get();
  if (sensor) {
    sensor->set_whitebal(sensor, 1);
    sensor->set_exposure_ctrl(sensor, 1);
    sensor->set_brightness(sensor, 0);
    Serial.printf("Camera %d sensor PID: 0x%04X\n", CAM_ID, sensor->id.PID);
  }

  return true;
}

// ================= SEND ALL BYTES =================
bool writeAll(WiFiClient& client, const uint8_t* data, size_t length) {
  size_t sent = 0;
  unsigned long lastProgress = millis();

  while (sent < length && client.connected()) {
    size_t n = client.write(data + sent, length - sent);
    if (n > 0) {
      sent += n;
      lastProgress = millis();
    } else {
      if (millis() - lastProgress > 2000) {
        return false;
      }
      delay(1);
    }
  }

  return sent == length;
}

// ================= RGB565 TO JPEG =================
bool getJpeg(uint8_t** jpg, size_t* jpgLen) {
  *jpg = nullptr;
  *jpgLen = 0;

  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    return false;
  }

  bool ok = frame2jpg(fb, jpegQuality, jpg, jpgLen);
  esp_camera_fb_return(fb);

  if (!ok || *jpg == nullptr) {
    if (*jpg) {
      free(*jpg);
      *jpg = nullptr;
    }
    *jpgLen = 0;
    return false;
  }

  return true;
}

// ================= HOME PAGE =================
void handleRoot() {
  char html[420];
  snprintf(
    html, sizeof(html),
    "<!doctype html><html><head>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>TRACE Camera %d</title></head>"
    "<body style='background:#111;color:#f0ede6;font-family:monospace;padding:16px'>"
    "<h2>TRACE ESP32-CAM #%d (%s)</h2>"
    "<img src='/stream' style='width:100%%;max-width:480px;height:auto;border:2px solid #d1522a'>"
    "</body></html>",
    CAM_ID, CAM_ID, WiFi.localIP().toString().c_str()
  );
  server.send(200, "text/html", html);
}

// ================= CONTROL ENDPOINT =================
void handleControl() {
  if (server.hasArg("var") && server.hasArg("val")) {
    String var = server.arg("var");
    int val = server.arg("val").toInt();
    if (var == "quality") {
      jpegQuality = (uint8_t)constrain(100 - val, 40, 85);
    }
  }
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "text/plain", "OK");
}

// ================= STATUS ENDPOINT =================
void handleStatus() {
  String ipStr = WiFi.localIP().toString();
  char json[200];
  snprintf(
    json, sizeof(json),
    "{\"cam_id\":%d,\"online\":true,\"ip\":\"%s\",\"rssi\":%d,\"stream\":\"http://%s/stream\",\"capture\":\"http://%s/capture\"}",
    CAM_ID, ipStr.c_str(), (int)WiFi.RSSI(), ipStr.c_str(), ipStr.c_str()
  );
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

// ================= SINGLE JPEG FRAME =================
void handleCapture() {
  uint8_t* jpg = nullptr;
  size_t jpgLen = 0;

  if (!getJpeg(&jpg, &jpgLen)) {
    server.send(503, "text/plain", "Camera frame capture or JPEG conversion failed");
    return;
  }

  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server.sendHeader("Pragma", "no-cache");
  server.sendHeader("Access-Control-Allow-Origin", "*");

  server.setContentLength(jpgLen);
  server.send(200, "image/jpeg", "");

  WiFiClient client = server.client();
  client.setNoDelay(true);
  writeAll(client, jpg, jpgLen);

  free(jpg);
}

// ================= LOW-LATENCY LIVE MJPEG STREAM =================
void handleStream() {
  WiFiClient client = server.client();
  client.setNoDelay(true);

  static const char STREAM_HEADER[] =
    "HTTP/1.1 200 OK\r\n"
    "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n"
    "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n"
    "Pragma: no-cache\r\n"
    "Connection: close\r\n"
    "Access-Control-Allow-Origin: *\r\n\r\n";

  if (!writeAll(client, (const uint8_t*)STREAM_HEADER, sizeof(STREAM_HEADER) - 1)) {
    client.stop();
    return;
  }

  char partHeader[128];

  while (client.connected() && WiFi.status() == WL_CONNECTED) {
    uint8_t* jpg = nullptr;
    size_t jpgLen = 0;

    if (!getJpeg(&jpg, &jpgLen)) {
      delay(2);
      continue;
    }

    int hdrLen = snprintf(
      partHeader, sizeof(partHeader),
      "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",
      (unsigned int)jpgLen
    );

    bool ok = writeAll(client, (const uint8_t*)partHeader, hdrLen) &&
              writeAll(client, jpg, jpgLen) &&
              writeAll(client, (const uint8_t*)"\r\n", 2);

    free(jpg);

    if (!ok) {
      break;
    }

    yield();
  }

  client.stop();
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  delay(200);

  Serial.println();
  Serial.printf("TRACE Camera %d booting...\n", CAM_ID);

  if (!initCamera()) {
    Serial.println("Camera initialization failed. Check sensor model and pin mapping.");
    while (true) {
      delay(1000);
    }
  }

  WiFi.mode(WIFI_STA);
  WiFi.config(cameraIP, gateway, subnet);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  esp_wifi_set_ps(WIFI_PS_NONE);
  WiFi.setHostname(MDNS_HOSTNAME);

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.printf("Connecting to Wi-Fi: %s\n", WIFI_SSID);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 12000) {
    delay(250);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("Wi-Fi connected! Camera %d IP: %s\n", CAM_ID, WiFi.localIP().toString().c_str());
    MDNS.begin(MDNS_HOSTNAME);
  } else {
    Serial.println("Wi-Fi still connecting in background...");
  }

  udp.begin(UDP_PORT);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/capture", HTTP_GET, handleCapture);
  server.on("/stream", HTTP_GET, handleStream);
  server.on("/control", HTTP_GET, handleControl);
  server.on("/status", HTTP_GET, handleStatus);

  server.onNotFound([]() {
    server.send(404, "text/plain", "Not found");
  });

  server.begin();

  Serial.printf("HTTP server started for Camera %d.\n", CAM_ID);
  Serial.printf("Live feed: http://%s/stream\n", WiFi.localIP().toString().c_str());
  announceCamera();
}

// ================= MAIN LOOP =================
void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    announceCamera();
  }
  server.handleClient();
}
