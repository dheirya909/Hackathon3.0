#include <WiFi.h>
#include <WiFiUdp.h>
#include <esp_wifi.h>
#include <Wire.h>
#include <DHT.h>

// ============================================================
// ACCESS POINT & UDP CONFIGURATION (ROVER 1 - AP HOST)
// ============================================================
const char* AP_SSID = "TRACE_ROBOT";
const char* AP_PASS = "12345678";

const char* BROADCAST_IP   = "192.168.4.255";
const int   TELEMETRY_PORT = 5005;
const int   COMMAND_PORT   = 5006; // Listens for manual arrow keys
const int   RELAY_PORT     = 5007; // Receives Rover 2 telemetry for AP broadcast relay

WiFiUDP udpTelemetry;
WiFiUDP udpCommand;
WiFiUDP udpRelay;
IPAddress rover2IP(0, 0, 0, 0);
unsigned long lastTelemetryMs = 0;

// ============================================================
// GPIO PIN DEFINITIONS
// ============================================================
#define MQ2_PIN       0
#define TRIG1_PIN     1
#define ECHO1_PIN     2
#define DHT_PIN       3
#define DHT_TYPE      DHT11
#define TRIG2_PIN     4
#define ECHO2_PIN     5
#define TRIG3_PIN     6
#define ECHO3_PIN     7
#define SDA_PIN       8
#define SCL_PIN       9
#define MOTOR1_PIN    20
#define MOTOR2_PIN    21

// ============================================================
// MPU REGISTERS
// ============================================================
#define IMU_ADDR      0x68
#define PWR_MGMT_1    0x6B
#define ACCEL_CONFIG  0x1C
#define GYRO_CONFIG   0x1B
#define ACCEL_XOUT_H  0x3B

DHT dht(DHT_PIN, DHT_TYPE);

void writeRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(IMU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

void readRegisters(uint8_t reg, uint8_t *buffer, uint8_t length) {
  Wire.beginTransmission(IMU_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom(IMU_ADDR, length);
  for (uint8_t i = 0; i < length; i++) {
    buffer[i] = Wire.available() ? Wire.read() : 0;
  }
}

int16_t makeInt16(uint8_t highByte, uint8_t lowByte) {
  return (int16_t)((highByte << 8) | lowByte);
}

float getDistance(uint8_t trigPin, uint8_t echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  long duration = pulseIn(echoPin, HIGH, 20000);
  if (duration == 0) return -1.0;
  return (duration * 0.0343) / 2.0;
}

void setMotors(bool m1, bool m2) {
  digitalWrite(MOTOR1_PIN, m1 ? HIGH : LOW);
  digitalWrite(MOTOR2_PIN, m2 ? HIGH : LOW);
}

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);

  // Motor Pins (Default OFF)
  pinMode(MOTOR1_PIN, OUTPUT);
  pinMode(MOTOR2_PIN, OUTPUT);
  setMotors(false, false);

  // Sensor Pins
  pinMode(TRIG1_PIN, OUTPUT);
  pinMode(ECHO1_PIN, INPUT);
  pinMode(TRIG2_PIN, OUTPUT);
  pinMode(ECHO2_PIN, INPUT);
  pinMode(TRIG3_PIN, OUTPUT);
  pinMode(ECHO3_PIN, INPUT);
  pinMode(MQ2_PIN, INPUT);
  dht.begin();

  // IMU
  Wire.begin(SDA_PIN, SCL_PIN);
  delay(50);
  writeRegister(PWR_MGMT_1, 0x00);
  delay(20);
  writeRegister(ACCEL_CONFIG, 0x00);
  writeRegister(GYRO_CONFIG, 0x00);

  // Start AP (Untouched stable configuration)
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(100);

  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);
  esp_wifi_set_max_tx_power(WIFI_POWER_8_5dBm);
  WiFi.softAP(AP_SSID, AP_PASS, 1, 0, 4);
  delay(500);

  // Start listening for manual arrow key commands and Rover 2 relay packets
  udpCommand.begin(COMMAND_PORT);
  udpRelay.begin(RELAY_PORT);
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  // 1. Process Arrow Key Control Packets
  int packetSize = udpCommand.parsePacket();
  if (packetSize) {
    char cmd = udpCommand.read();
    if (cmd == '2' && udpCommand.available()) {
      // Command targeted for Rover 2 ("2F", "2L", "2R", "2S") -> relay to Rover 2
      char r2cmd = udpCommand.read();
      if (rover2IP[0] != 0) {
        udpCommand.beginPacket(rover2IP, COMMAND_PORT);
        udpCommand.write((uint8_t)r2cmd);
        udpCommand.endPacket();
      }
    } else if (cmd == 'F') {        // Forward
      setMotors(true, true);
    } else if (cmd == 'L') { // Left Turn
      setMotors(false, true);
    } else if (cmd == 'R') { // Right Turn
      setMotors(true, false);
    } else if (cmd == 'S') { // Stop
      setMotors(false, false);
    }
    while (udpCommand.available()) {
      udpCommand.read();
    }
  }

  // 2. Relay Rover 2 Telemetry to Laptop via AP Broadcast
  int relaySize = udpRelay.parsePacket();
  if (relaySize) {
    rover2IP = udpRelay.remoteIP();
    char r2Buf[512];
    int len = udpRelay.read(r2Buf, sizeof(r2Buf) - 1);
    if (len > 0) {
      r2Buf[len] = '\0';
      udpTelemetry.beginPacket(BROADCAST_IP, TELEMETRY_PORT);
      udpTelemetry.write((const uint8_t*)r2Buf, len);
      udpTelemetry.endPacket();
    }
  }

  // 3. Transmit Rover 1 Telemetry (every 60ms)
  unsigned long now = millis();
  if (now - lastTelemetryMs >= 60) {
    lastTelemetryMs = now;

    uint8_t buffer[14];
    readRegisters(ACCEL_XOUT_H, buffer, 14);
    int16_t ax = makeInt16(buffer[0], buffer[1]);
    int16_t ay = makeInt16(buffer[2], buffer[3]);
    int16_t az = makeInt16(buffer[4], buffer[5]);
    int16_t gx = makeInt16(buffer[8], buffer[9]);
    int16_t gy = makeInt16(buffer[10], buffer[11]);
    int16_t gz = makeInt16(buffer[12], buffer[13]);

    float dist1 = getDistance(TRIG1_PIN, ECHO1_PIN);
    float dist2 = getDistance(TRIG2_PIN, ECHO2_PIN);
    float dist3 = getDistance(TRIG3_PIN, ECHO3_PIN);

    int mq2Val = analogRead(MQ2_PIN);
    float temp = dht.readTemperature();
    float hum  = dht.readHumidity();
    if (isnan(temp)) temp = 0.0;
    if (isnan(hum))  hum  = 0.0;

    String payload = "{";
    payload += "\"rover\":1,";
    payload += "\"ax\":" + String(ax) + ",";
    payload += "\"ay\":" + String(ay) + ",";
    payload += "\"az\":" + String(az) + ",";
    payload += "\"gx\":" + String(gx) + ",";
    payload += "\"gy\":" + String(gy) + ",";
    payload += "\"gz\":" + String(gz) + ",";
    payload += "\"mq2\":" + String(mq2Val) + ",";
    payload += "\"d1\":" + String(dist1, 1) + ",";
    payload += "\"d2\":" + String(dist2, 1) + ",";
    payload += "\"d3\":" + String(dist3, 1) + ",";
    payload += "\"temp\":" + String(temp, 1) + ",";
    payload += "\"hum\":" + String(hum, 1);
    payload += "}";

    udpTelemetry.beginPacket(BROADCAST_IP, TELEMETRY_PORT);
    udpTelemetry.write((const uint8_t*)payload.c_str(), payload.length());
    udpTelemetry.endPacket();
  }
}
