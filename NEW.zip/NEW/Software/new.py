import socket
import json
import threading
import time
import math
import os
import urllib.request
import tkinter as tk
import customtkinter as ctk

try:
    from PIL import Image, ImageTk
    import io
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

TELEMETRY_PORT = 5005
COMMAND_PORT   = 5006
ESP_AP_IP      = "192.168.4.1"

BG_DARK        = "#0D0D0D"
GRID_BG_LINE   = "#171717"
CARD_BG        = "#151515"
CARD_INNER_BG  = "#101010"
BORDER_CREAM   = "#F2EFE9"
SHADOW_CREAM   = "#F2EFE9"
ACCENT_ORANGE  = "#FF7919"
ACCENT_RED     = "#FF3B30"
ACCENT_GREEN   = "#2ECC71"
TEXT_WHITE     = "#F2EFE9"
TEXT_MUTED     = "#7E7E7E"
R1_COLOR       = "#F2EFE9"
R1_ACCENT      = "#D4522A"
R2_COLOR       = "#38BDF8"
R2_ACCENT      = "#0284C7"

GRID_RES_CM       = 5.0
MAX_SONAR_CM      = 220.0
FORWARD_SPEED_CMS = 18.0
TURN_RATE_DPS     = 55.0

AUTO_FRONT_BLOCK_CM    = 32.0
AUTO_SIDE_BLOCK_CM     = 25.0
AUTO_SIDE_TOO_CLOSE_CM = 14.0
AUTO_CMD_INTERVAL_S    = 0.15
AUTO_TURN_HOLD_S       = 0.30

# --- Obstacle safety tuning ---
AUTO_FRONT_STOP_CM     = 18.0   # hard stop: never send F below this
AUTO_DATA_STALE_S      = 0.6    # stop if telemetry older than this
AUTO_STOP_PAUSE_S      = 0.25   # full stop before choosing a turn
AUTO_FILTER_N          = 3      # conservative min over last N readings
AUTO_NOECHO_NEAR_CM    = 60.0   # if last valid reading was this close...
AUTO_NOECHO_MEMORY_S   = 1.0    # ...within this window, a lost echo means BLOCKED
AUTO_CLEAR_HYSTERESIS  = 8.0    # extra clearance needed to abort a committed turn

# --- Wall-hugging (maze solving) tuning ---
AUTO_HUG_OPEN_CM       = 45.0   # hugged-side distance beyond this = wall lost / opening
AUTO_HUG_FAR_CM        = 30.0   # drifting farther than this (but < OPEN) -> nudge toward wall
AUTO_HUG_ADVANCE_S     = 0.8    # drive forward this long after wall is lost before turning into the opening
AUTO_HUG_CORNER_TURN_S = 1.5    # committed turn duration into an opening (~90 deg)
AUTO_HUG_MEMORY_S      = 3.0    # wall counts as "recently seen" for this long

ctk.set_appearance_mode("dark")


class TraceApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("TRACE // Fleet Control - Dual-Rover Ultrasonic SLAM")
        self.geometry("1280x780")
        self.minsize(1100, 680)
        self.configure(fg_color=BG_DARK)

        self.last_packet_time = 0
        self.data_store = {}
        self.current_movement = "STOPPED"

        self.cmd_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.selected_rover = 1
        self.rx_total = 0
        self.rx_dropped = 0
        self.ip_to_rover = {}
        self.state_lock = threading.Lock()

        self.rovers = {
            1: {
                "id": 1,
                "name": "R1",
                "role": "Right-Wall",
                "preference": "RIGHT",
                "ip": None,
                "last_rx": 0.0,
                "data": {},
                "mode": "STOP",
                "movement": "STOPPED",
                "possible_routes": ["F", "L", "R"],
                "assigned_route": "STANDBY",
                "last_auto_cmd": b'S',
                "last_auto_send": 0.0,
                "auto_turn_until": 0.0,
                "auto_turn_cmd": b'S',
                "auto_turn_move": "STOPPED",
                "auto_turn_label": "STANDBY",
                "auto_turn_force": False,
                "auto_stop_until": 0.0,
                "hug_seen_ts": 0.0,
                "hug_open_since": 0.0,
                "hist": {},
                "lastv": {},
                "eval_rx": 0.0,
                "x": 0.0,
                "y": 0.0,
                "heading": 0.0,
                "gz_bias": 0.0,
                "gz_calibrated": False,
                "gz_samples": 0,
                "trail": [(0.0, 0.0)],
                "color": R1_COLOR,
                "accent": R1_ACCENT,
            },
            2: {
                "id": 2,
                "name": "R2",
                "role": "Left-Wall",
                "preference": "LEFT",
                "ip": None,
                "last_rx": 0.0,
                "data": {},
                "mode": "STOP",
                "movement": "STOPPED",
                "possible_routes": ["F", "L", "R"],
                "assigned_route": "STANDBY",
                "last_auto_cmd": b'S',
                "last_auto_send": 0.0,
                "auto_turn_until": 0.0,
                "auto_turn_cmd": b'S',
                "auto_turn_move": "STOPPED",
                "auto_turn_label": "STANDBY",
                "auto_turn_force": False,
                "auto_stop_until": 0.0,
                "hug_seen_ts": 0.0,
                "hug_open_since": 0.0,
                "hist": {},
                "lastv": {},
                "eval_rx": 0.0,
                "x": 0.0,
                "y": -40.0,
                "heading": 0.0,
                "gz_bias": 0.0,
                "gz_calibrated": False,
                "gz_samples": 0,
                "trail": [(0.0, -40.0)],
                "color": R2_COLOR,
                "accent": R2_ACCENT,
            }
        }

        self.obstacle_grid = {}
        self.beam_history = {}
        self.explored_cells = set()
        self.map_events = []

        self.view_mode = "MAP"
        self.active_cam = 1
        self.cam_URLs = {
            1: "http://192.168.4.11/stream",
            2: "http://192.168.4.12/stream",
        }
        self.latest_cam_image = None
        self._cam_frame_id = 0
        self._cam_photo_key = None
        self._tk_cam_photo = None
        self.cam_status_text = "CAMERA STREAM STANDBY"

        self.px_per_cm = 1.45
        self.pan_offset_x = 0.0
        self.pan_offset_y = 0.0
        self._drag_start = None
        self.last_odom_time = time.time()

        self.build_ui()

        self.bind("<KeyPress>", self.handle_key_press)
        self.bind("<KeyRelease>", self.handle_key_release)

        self.udp_thread = threading.Thread(target=self.udp_listener, daemon=True)
        self.udp_thread.start()

        self.cam_thread = threading.Thread(target=self.camera_stream_worker, daemon=True)
        self.cam_thread.start()

        self.check_connection_watchdog()
        self.ui_slam_tick()

    def _create_brutalist_card(self, parent, bg_color=CARD_BG, border_color=BORDER_CREAM,
                               shadow_color=SHADOW_CREAM, shadow_offset=4):
        wrapper = tk.Frame(parent, bg=BG_DARK, highlightthickness=0, bd=0)
        shadow = tk.Frame(wrapper, bg=shadow_color, highlightthickness=0, bd=0)
        shadow.place(
            relx=0, rely=0, relwidth=1, relheight=1,
            x=shadow_offset, y=shadow_offset,
            width=-shadow_offset, height=-shadow_offset
        )
        card = tk.Frame(
            wrapper,
            bg=bg_color,
            highlightbackground=border_color,
            highlightcolor=border_color,
            highlightthickness=1,
            bd=0
        )
        card.place(
            relx=0, rely=0, relwidth=1, relheight=1,
            x=0, y=0,
            width=-shadow_offset, height=-shadow_offset
        )
        return wrapper, card

    def build_ui(self):
        self.bg_canvas = tk.Canvas(self, bg=BG_DARK, highlightthickness=0, bd=0)
        self.bg_canvas.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.bg_canvas.bind("<Configure>", self._draw_window_bg_grid)
        self.bg_canvas.bind("<Button-1>", lambda e: self.focus_set())

        top_bar = tk.Frame(self, bg=BG_DARK, height=68)
        top_bar.pack(fill="x", padx=28, pady=(14, 6))
        top_bar.pack_propagate(False)

        title_container = tk.Frame(top_bar, bg=BG_DARK)
        title_container.pack(side="left", anchor="center")

        lbl_trace = tk.Label(
            title_container,
            text="TRACE",
            font=("Helvetica", 30, "bold"),
            fg=TEXT_WHITE,
            bg=BG_DARK
        )
        lbl_trace.pack(side="left")

        lbl_dot = tk.Label(
            title_container,
            text=" .",
            font=("Helvetica", 30, "bold"),
            fg=ACCENT_ORANGE,
            bg=BG_DARK
        )
        lbl_dot.pack(side="left")

        status_wrap, self.status_card = self._create_brutalist_card(
            top_bar, bg_color=ACCENT_ORANGE, border_color=BORDER_CREAM,
            shadow_color=SHADOW_CREAM, shadow_offset=4
        )
        status_wrap.configure(width=310, height=48)
        status_wrap.pack(side="right", anchor="center")
        status_wrap.pack_propagate(False)

        self.status_btn = tk.Label(
            self.status_card,
            text="R1: ○ OFF  |  R2: ○ OFF",
            font=("Menlo", 12, "bold"),
            fg=TEXT_WHITE,
            bg=ACCENT_ORANGE
        )
        self.status_btn.pack(fill="both", expand=True)

        divider = tk.Frame(self, bg="#7A7A7A", height=1)
        divider.pack(fill="x", padx=0, pady=(2, 10))

        main_area = tk.Frame(self, bg=BG_DARK)
        main_area.pack(fill="both", expand=True, padx=28, pady=(0, 6))

        left_col = tk.Frame(main_area, bg=BG_DARK)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 20))

        right_col = tk.Frame(main_area, bg=BG_DARK, width=510)
        right_col.pack(side="right", fill="y")
        right_col.pack_propagate(False)

        sub_hdr = tk.Frame(left_col, bg=BG_DARK)
        sub_hdr.pack(fill="x", pady=(0, 8))

        tag_box = tk.Label(
            sub_hdr,
            text="  COMMAND CENTRE // 2X  ",
            font=("Menlo", 11, "bold"),
            fg="#0D0D0D",
            bg=BORDER_CREAM,
            padx=6,
            pady=5
        )
        tag_box.pack(anchor="w", pady=(0, 6))

        fleet_lbl = tk.Label(
            sub_hdr,
            text="FLEET CONTROL",
            font=("Helvetica", 32, "bold"),
            fg=TEXT_WHITE,
            bg=BG_DARK
        )
        fleet_lbl.pack(anchor="w")

        map_wrap, self.cam_frame = self._create_brutalist_card(
            left_col, bg_color=CARD_BG, border_color=BORDER_CREAM,
            shadow_color=SHADOW_CREAM, shadow_offset=5
        )
        map_wrap.pack(fill="both", expand=True, pady=(2, 4))

        map_hdr = tk.Frame(self.cam_frame, bg=CARD_BG)
        map_hdr.pack(fill="x", padx=12, pady=(8, 6))

        self.map_title_lbl = tk.Label(
            map_hdr,
            text="MAP // SHARED DUAL-ROVER ULTRASONIC SLAM",
            font=("Menlo", 10, "bold"),
            fg=ACCENT_ORANGE,
            bg=CARD_BG
        )
        self.map_title_lbl.pack(side="left")

        hdr_btns = tk.Frame(map_hdr, bg=CARD_BG)
        hdr_btns.pack(side="right")

        self.btn_save_map = self._make_tactical_btn(
            hdr_btns, "SAVE MAP", self.action_save_map, active=False, bordered=True, padx=10
        )
        self.btn_save_map.pack(side="right", padx=(6, 0))

        self.btn_view_map = self._make_tactical_btn(
            hdr_btns, "MAP", lambda: self.set_view_mode("MAP"), active=True, bordered=False, padx=6
        )
        self.btn_view_map.pack(side="right", padx=(0, 2))

        self.btn_view_cam = self._make_tactical_btn(
            hdr_btns, "CAMERA", lambda: self.set_view_mode("CAMERA"), active=False, bordered=False, padx=6
        )
        self.btn_view_cam.pack(side="right", padx=(6, 0))

        self.btn_cam2 = self._make_tactical_btn(
            hdr_btns, "CAM 2", lambda: self.select_camera(2), active=False, bordered=False, padx=6
        )
        self.btn_cam2.pack(side="right", padx=(0, 2))

        self.btn_cam1 = self._make_tactical_btn(
            hdr_btns, "CAM 1", lambda: self.select_camera(1), active=True, bordered=False, padx=6
        )
        self.btn_cam1.pack(side="right", padx=(0, 0))

        self.canvas_holder = tk.Frame(self.cam_frame, bg="#111111", highlightthickness=1, highlightbackground="#262626")
        self.canvas_holder.pack(fill="both", expand=True, padx=12, pady=(0, 6))

        self.map_canvas = tk.Canvas(self.canvas_holder, bg="#111111", highlightthickness=0, bd=0, cursor="crosshair")
        self.map_canvas.pack(fill="both", expand=True)

        self.map_canvas.bind("<ButtonPress-1>", self._on_map_press)
        self.map_canvas.bind("<B1-Motion>", self._on_map_drag)
        self.map_canvas.bind("<Double-Button-1>", self._on_map_recenter)
        self.map_canvas.bind("<MouseWheel>", self._on_map_zoom)
        self.map_canvas.bind("<Button-4>", self._on_map_zoom)
        self.map_canvas.bind("<Button-5>", self._on_map_zoom)

        map_footer = tk.Frame(self.cam_frame, bg=CARD_BG)
        map_footer.pack(fill="x", padx=12, pady=(0, 6))

        self.lbl_map_footer = tk.Label(
            map_footer,
            text="SHARED MAP // EXPLORED 0.0 m² // R1(R) & R2(L)",
            font=("Menlo", 10, "bold"),
            fg=TEXT_WHITE,
            bg=CARD_BG
        )
        self.lbl_map_footer.pack(side="left")

        btn_clear_map = self._make_tactical_btn(
            map_footer, "CLEAR MAP", self.action_clear_map, active=False, bordered=True, padx=7
        )
        btn_clear_map.pack(side="right", padx=(5, 0))

        btn_reset_pose = self._make_tactical_btn(
            map_footer, "RESET POSE", self.action_reset_pose, active=False, bordered=True, padx=7
        )
        btn_reset_pose.pack(side="right")

        self.ctrl_banner = ctk.CTkLabel(
            self.cam_frame,
            text="[ MANUAL CONTROL: Use Arrow Keys (↑ Forward | ← Left | → Right | Release Stop) ]\nState: STOPPED",
            font=ctk.CTkFont(family="Menlo", size=10, weight="bold"),
            text_color="#9E9E9E",
            fg_color="#101010",
            corner_radius=2,
            height=28
        )
        self.ctrl_banner.pack(side="bottom", fill="x", padx=12, pady=(0, 8))

        env_wrap, self.card_env = self._create_brutalist_card(right_col)
        env_wrap.configure(height=112)
        env_wrap.pack(fill="x", pady=(0, 10))
        env_wrap.pack_propagate(False)
        self._build_env_card(self.card_env)

        sonar_wrap, self.card_sonar = self._create_brutalist_card(right_col)
        sonar_wrap.configure(height=188)
        sonar_wrap.pack(fill="x", pady=(0, 10))
        sonar_wrap.pack_propagate(False)
        self._build_sonar_card(self.card_sonar)

        imu_wrap, self.card_imu = self._create_brutalist_card(right_col)
        imu_wrap.configure(height=124)
        imu_wrap.pack(fill="x", pady=(0, 10))
        imu_wrap.pack_propagate(False)
        self._build_imu_card(self.card_imu)

        cmd_wrap, self.card_cmd = self._create_brutalist_card(right_col)
        cmd_wrap.configure(height=136)
        cmd_wrap.pack(fill="x", pady=(0, 10))
        cmd_wrap.pack_propagate(False)
        self._build_cmd_card(self.card_cmd)

        evt_wrap, self.card_evt = self._create_brutalist_card(right_col)
        evt_wrap.configure(height=54)
        evt_wrap.pack(fill="x", pady=(0, 2))
        evt_wrap.pack_propagate(False)
        self._build_event_card(self.card_evt)

        bottom_bar = tk.Frame(self, bg=BG_DARK, height=24)
        bottom_bar.pack(fill="x", side="bottom", padx=28, pady=(0, 6))

        self.lbl_bottom_status = tk.Label(
            bottom_bar,
            text=f"UDP :{TELEMETRY_PORT}  //  AP IP: {ESP_AP_IP}  //  SELECTED: ROVER 1  //  RX TOTAL 0  //  DROPPED 0",
            font=("Menlo", 10),
            fg=TEXT_MUTED,
            bg=BG_DARK,
            anchor="w"
        )
        self.lbl_bottom_status.pack(side="left", fill="x")

    def _make_tactical_btn(self, parent, text, command, active=False, bordered=True, padx=8, pady=3):
        bg = ACCENT_ORANGE if active else "#0F0F0F"
        fg = TEXT_WHITE if active else "#CFCFCF"
        hl_color = BORDER_CREAM if bordered else ("#D4522A" if active else "#2A2A2A")
        lbl = tk.Label(
            parent,
            text=text,
            font=("Menlo", 9, "bold"),
            fg=fg,
            bg=bg,
            padx=padx,
            pady=pady,
            highlightbackground=hl_color,
            highlightcolor=hl_color,
            highlightthickness=1,
            cursor="hand2"
        )
        lbl.bind("<Button-1>", lambda e: (self.focus_set(), command()))
        return lbl

    def _set_btn_style(self, btn, active=False, bordered=True):
        bg = ACCENT_ORANGE if active else "#0F0F0F"
        fg = TEXT_WHITE
        hl = BORDER_CREAM if bordered else (ACCENT_ORANGE if active else "#262626")
        btn.configure(bg=bg, fg=fg, highlightbackground=hl, highlightcolor=hl)

    def _build_env_card(self, card):
        hdr = tk.Label(
            card,
            text="ENVIRONMENT // SELECTED ROVER",
            font=("Menlo", 10, "bold"),
            fg=ACCENT_ORANGE,
            bg=CARD_BG
        )
        hdr.pack(anchor="w", padx=14, pady=(8, 4))

        body = tk.Frame(card, bg=CARD_BG)
        body.pack(fill="both", expand=True, padx=14, pady=(0, 8))

        col_temp = tk.Frame(body, bg=CARD_BG)
        col_temp.pack(side="left", fill="y", padx=(0, 26))
        tk.Label(col_temp, text="TEMPERATURE", font=("Menlo", 9), fg=TEXT_MUTED, bg=CARD_BG).pack(anchor="w")
        self.lbl_temp_val = tk.Label(
            col_temp, text="-- °C", font=("Menlo", 19, "bold"), fg=TEXT_WHITE, bg=CARD_BG
        )
        self.lbl_temp_val.pack(anchor="w", pady=(4, 0))

        col_hum = tk.Frame(body, bg=CARD_BG)
        col_hum.pack(side="left", fill="y", padx=(0, 26))
        tk.Label(col_hum, text="HUMIDITY", font=("Menlo", 9), fg=TEXT_MUTED, bg=CARD_BG).pack(anchor="w")
        self.lbl_hum_val = tk.Label(
            col_hum, text="-- %", font=("Menlo", 19, "bold"), fg=TEXT_WHITE, bg=CARD_BG
        )
        self.lbl_hum_val.pack(anchor="w", pady=(4, 0))

        col_mq2 = tk.Frame(body, bg=CARD_BG)
        col_mq2.pack(side="left", fill="y", padx=(0, 14))
        tk.Label(col_mq2, text="MQ-2 HAZ≥1800", font=("Menlo", 9), fg=TEXT_MUTED, bg=CARD_BG).pack(anchor="w")
        self.lbl_mq2_val = tk.Label(
            col_mq2, text="--", font=("Menlo", 18, "bold"), fg=TEXT_WHITE, bg=CARD_BG
        )
        self.lbl_mq2_val.pack(anchor="w", pady=(2, 3))

        self.mq2_bar_canvas = tk.Canvas(col_mq2, width=96, height=6, bg="#363636", highlightthickness=0, bd=0)
        self.mq2_bar_canvas.pack(anchor="w")
        self.mq2_bar_fill = self.mq2_bar_canvas.create_rectangle(0, 0, 3, 6, fill=ACCENT_ORANGE, width=0)

        self.env_status_box = tk.Frame(
            body, bg=CARD_BG, highlightbackground=BORDER_CREAM, highlightthickness=1, width=110, height=50
        )
        self.env_status_box.pack(side="right", anchor="center")
        self.env_status_box.pack_propagate(False)

        self.lbl_env_state = tk.Label(
            self.env_status_box, text="NO DATA", font=("Menlo", 10, "bold"), fg=TEXT_MUTED, bg=CARD_BG
        )
        self.lbl_env_state.pack(fill="both", expand=True)

    def _build_sonar_card(self, card):
        hdr = tk.Label(
            card,
            text="ULTRASONIC // SELECTED ROVER PROXIMITY",
            font=("Menlo", 10, "bold"),
            fg=ACCENT_ORANGE,
            bg=CARD_BG
        )
        hdr.pack(anchor="w", padx=14, pady=(8, 4))

        body = tk.Frame(card, bg=CARD_BG)
        body.pack(fill="both", expand=True, padx=14, pady=(0, 10))

        self.prox_canvas = tk.Canvas(
            body, width=258, height=136, bg="#1B1B1B",
            highlightbackground="#454545", highlightthickness=1, bd=0
        )
        self.prox_canvas.pack(side="left", fill="y", padx=(0, 14))

        right_rows = tk.Frame(body, bg=CARD_BG)
        right_rows.pack(side="right", fill="both", expand=True)

        self.lbl_sonar_left = self._create_sonar_row(right_rows, "LEFT")
        self.lbl_sonar_front = self._create_sonar_row(right_rows, "FRONT")
        self.lbl_sonar_right = self._create_sonar_row(right_rows, "RIGHT")

        self.lbl_range_status = tk.Label(
            right_rows,
            text="RANGE CLEAR",
            font=("Menlo", 10),
            fg=TEXT_MUTED,
            bg=CARD_BG,
            anchor="w"
        )
        self.lbl_range_status.pack(fill="x", pady=(4, 0))

        self.after(50, self._draw_proximity_mini_grid)

    def _create_sonar_row(self, parent, label_text):
        row = tk.Frame(parent, bg=CARD_INNER_BG, height=28)
        row.pack(fill="x", pady=(0, 5))
        row.pack_propagate(False)

        tk.Label(
            row, text=label_text, font=("Menlo", 9), fg=TEXT_MUTED, bg=CARD_INNER_BG
        ).pack(side="left", padx=8)

        val_lbl = tk.Label(
            row, text="--", font=("Menlo", 11, "bold"), fg=TEXT_WHITE, bg=CARD_INNER_BG
        )
        val_lbl.pack(side="right", padx=8)
        return val_lbl

    def _draw_proximity_mini_grid(self, d_front=-1, d_left=-1, d_right=-1):
        c = self.prox_canvas
        c.delete("all")
        w = int(c.winfo_width()) if c.winfo_width() > 20 else 258
        h = int(c.winfo_height()) if c.winfo_height() > 20 else 136
        cols, rows = 7, 6
        cw = w / cols
        rh = h / rows

        c.create_rectangle(3 * cw, 0, 4 * cw, h, fill="#383838", width=0)
        c.create_rectangle(0, 5 * rh, w, h, fill="#2A2A2A", width=0)

        if 0 < d_front <= 160:
            if d_front < 22:
                f_row = 4
                f_col_color = ACCENT_RED
            elif d_front < 45:
                f_row = 3
                f_col_color = ACCENT_ORANGE
            elif d_front < 75:
                f_row = 2
                f_col_color = ACCENT_ORANGE
            elif d_front < 115:
                f_row = 1
                f_col_color = "#E67E22"
            else:
                f_row = 0
                f_col_color = "#D4AC0D"
            c.create_rectangle(
                3 * cw + 1, f_row * rh + 1, 4 * cw - 1, (f_row + 1) * rh - 1,
                fill=f_col_color, width=0
            )

        if 0 < d_left <= 160:
            if d_left < 28:
                l_col = 2
                l_color = ACCENT_RED if d_left < 18 else ACCENT_ORANGE
            elif d_left < 70:
                l_col = 1
                l_color = ACCENT_ORANGE
            else:
                l_col = 0
                l_color = "#E67E22"
            c.create_rectangle(
                l_col * cw + 1, 3 * rh + 1, (l_col + 1) * cw - 1, 5 * rh - 1,
                fill=l_color, width=0
            )

        if 0 < d_right <= 160:
            if d_right < 28:
                r_col = 4
                r_color = ACCENT_RED if d_right < 18 else ACCENT_ORANGE
            elif d_right < 70:
                r_col = 5
                r_color = ACCENT_ORANGE
            else:
                r_col = 6
                r_color = "#E67E22"
            c.create_rectangle(
                r_col * cw + 1, 3 * rh + 1, (r_col + 1) * cw - 1, 5 * rh - 1,
                fill=r_color, width=0
            )

        for i in range(1, cols):
            x = i * cw
            c.create_line(x, 0, x, h, fill="#4A4A4A", width=1)
        for j in range(1, rows):
            y = j * rh
            c.create_line(0, y, w, y, fill="#4A4A4A", width=1)

        rx1 = 3 * cw + 5
        ry1 = 5 * rh + 3
        rx2 = 4 * cw - 5
        ry2 = h - 3
        r_name = f"R{self.selected_rover}"
        c.create_rectangle(rx1, ry1, rx2, ry2, fill=BORDER_CREAM, outline=ACCENT_ORANGE, width=2)
        c.create_text((rx1 + rx2) / 2, (ry1 + ry2) / 2, text=r_name, font=("Menlo", 9, "bold"), fill="#0D0D0D")

    def _build_imu_card(self, card):
        hdr = tk.Label(
            card,
            text="MPU6050 // SELECTED ROVER IMU",
            font=("Menlo", 10, "bold"),
            fg=ACCENT_ORANGE,
            bg=CARD_BG
        )
        hdr.pack(anchor="w", padx=14, pady=(8, 4))

        grid_frame = tk.Frame(card, bg=CARD_BG)
        grid_frame.pack(fill="both", expand=True, padx=14, pady=(0, 8))

        left_col = tk.Frame(grid_frame, bg=CARD_BG)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 12))

        right_col = tk.Frame(grid_frame, bg=CARD_BG)
        right_col.pack(side="right", fill="both", expand=True)

        self.imu_widgets = {}
        for axis in ("AX", "AY", "AZ"):
            self.imu_widgets[axis] = self._create_imu_bar_row(left_col, axis)
        for axis in ("GX", "GY", "GZ"):
            self.imu_widgets[axis] = self._create_imu_bar_row(right_col, axis)

    def _create_imu_bar_row(self, parent, axis_name):
        row = tk.Frame(parent, bg=CARD_BG)
        row.pack(fill="x", pady=3)

        tk.Label(
            row, text=axis_name, font=("Menlo", 9, "bold"), fg=TEXT_MUTED, bg=CARD_BG, width=3, anchor="w"
        ).pack(side="left")

        bar_canvas = tk.Canvas(row, width=136, height=7, bg="#383838", highlightthickness=0, bd=0)
        bar_canvas.pack(side="left", padx=8)
        fill_id = bar_canvas.create_rectangle(0, 0, 68, 7, fill=ACCENT_ORANGE, width=0)

        val_lbl = tk.Label(
            row, text="--", font=("Menlo", 9, "bold"), fg=TEXT_WHITE, bg=CARD_BG, width=6, anchor="e"
        )
        val_lbl.pack(side="right")
        return (bar_canvas, fill_id, val_lbl)

    def _build_cmd_card(self, card):
        hdr = tk.Label(
            card,
            text="COMMAND CENTRE // FLEET & ROVER CONTROL",
            font=("Menlo", 10, "bold"),
            fg=ACCENT_ORANGE,
            bg=CARD_BG
        )
        hdr.pack(anchor="w", padx=14, pady=(8, 6))

        btn_row = tk.Frame(card, bg=CARD_BG)
        btn_row.pack(fill="x", padx=14, pady=(0, 8))

        self.btn_r1 = self._make_tactical_btn(
            btn_row, "ROVER 1 (R)", lambda: self.select_rover(1), active=True, bordered=False, padx=7, pady=4
        )
        self.btn_r1.pack(side="left", padx=(0, 2))

        self.btn_r2 = self._make_tactical_btn(
            btn_row, "ROVER 2 (L)", lambda: self.select_rover(2), active=False, bordered=False, padx=7, pady=4
        )
        self.btn_r2.pack(side="left", padx=(0, 8))

        self.btn_mode_auto = self._make_tactical_btn(
            btn_row, "AUTO", lambda: self.set_rover_mode("AUTO"), active=False, bordered=True, padx=8, pady=4
        )
        self.btn_mode_auto.pack(side="left", padx=(0, 3))

        self.btn_mode_manual = self._make_tactical_btn(
            btn_row, "MANUAL", lambda: self.set_rover_mode("MANUAL"), active=False, bordered=True, padx=8, pady=4
        )
        self.btn_mode_manual.pack(side="left", padx=(0, 3))

        self.btn_mode_stop = self._make_tactical_btn(
            btn_row, "STOP", lambda: self.set_rover_mode("STOP"), active=True, bordered=True, padx=8, pady=4
        )
        self.btn_mode_stop.pack(side="left", padx=(0, 8))

        self.btn_all_auto = self._make_tactical_btn(
            btn_row, "ALL AUTO", self.action_all_auto, active=False, bordered=True, padx=6, pady=4
        )
        self.btn_all_auto.pack(side="left", padx=(0, 3))

        self.btn_all_stop = self._make_tactical_btn(
            btn_row, "ALL STOP", self.action_all_stop, active=False, bordered=True, padx=6, pady=4
        )
        self.btn_all_stop.pack(side="left")

        self.lbl_fleet_state = tk.Label(
            card,
            text="R1[R]: OFF/--  //  R2[L]: OFF/--",
            font=("Menlo", 10, "bold"),
            fg=TEXT_WHITE,
            bg=CARD_BG,
            anchor="w"
        )
        self.lbl_fleet_state.pack(fill="x", padx=14, pady=(0, 3))

        pose_row = tk.Frame(card, bg=CARD_BG)
        pose_row.pack(fill="x", padx=14)

        self.lbl_fleet_pose = tk.Label(
            pose_row,
            text="R1(0,0,0°)   R2(0,-40,0°)",
            font=("Menlo", 10),
            fg=TEXT_MUTED,
            bg=CARD_BG,
            anchor="w"
        )
        self.lbl_fleet_pose.pack(side="left")

        self.lbl_drive_hint = tk.Label(
            pose_row,
            text="KEYS: ↑ FWD | ←/→ TURN | REL STOP",
            font=("Menlo", 8),
            fg="#5A5A5A",
            bg=CARD_BG,
            anchor="e"
        )
        self.lbl_drive_hint.pack(side="right")

    def _build_event_card(self, card):
        inner = tk.Frame(card, bg=CARD_BG)
        inner.pack(fill="both", expand=True, padx=10, pady=8)

        self.btn_add_firebase = self._make_tactical_btn(
            inner, "ADD TO FIREBASE", self.action_add_event, active=False, bordered=True, padx=12, pady=5
        )
        self.btn_add_firebase.pack(side="right", padx=(8, 0))

        entry_box = tk.Frame(inner, bg=CARD_INNER_BG, highlightbackground=BORDER_CREAM, highlightthickness=1)
        entry_box.pack(side="left", fill="both", expand=True)

        self.event_placeholder = "EVENT NAME  (e.g. Gas leak, corridor B)"
        self.entry_event = tk.Entry(
            entry_box,
            bg=CARD_INNER_BG,
            fg=TEXT_MUTED,
            insertbackground=TEXT_WHITE,
            font=("Menlo", 10),
            relief="flat",
            bd=0,
            highlightthickness=0
        )
        self.entry_event.insert(0, self.event_placeholder)
        self.entry_event.pack(fill="both", expand=True, padx=8, pady=4)

        self.entry_event.bind("<FocusIn>", self._on_entry_focus_in)
        self.entry_event.bind("<FocusOut>", self._on_entry_focus_out)
        self.entry_event.bind("<Return>", lambda e: self.action_add_event())
        self.entry_event.bind("<Escape>", lambda e: self.focus_set())

    def _on_entry_focus_in(self, _event):
        if self.entry_event.get() == self.event_placeholder:
            self.entry_event.delete(0, "end")
            self.entry_event.configure(fg=TEXT_WHITE)

    def _on_entry_focus_out(self, _event):
        if not self.entry_event.get().strip():
            self.entry_event.delete(0, "end")
            self.entry_event.insert(0, self.event_placeholder)
            self.entry_event.configure(fg=TEXT_MUTED)

    def _draw_window_bg_grid(self, _event=None):
        c = self.bg_canvas
        c.delete("grid")
        w = c.winfo_width()
        h = c.winfo_height()
        step = 48
        for x in range(0, w, step):
            c.create_line(x, 0, x, h, fill=GRID_BG_LINE, tags="grid")
        for y in range(0, h, step):
            c.create_line(0, y, w, y, fill=GRID_BG_LINE, tags="grid")

    def select_rover(self, rover_id):
        self.selected_rover = rover_id
        self._set_btn_style(self.btn_r1, active=(rover_id == 1), bordered=False)
        self._set_btn_style(self.btn_r2, active=(rover_id == 2), bordered=False)

        r_mode = self.rovers[rover_id]["mode"]
        self._update_mode_buttons(r_mode)
        self.update_telemetry_ui()

    def _reset_auto_state(self, r):
        r["auto_turn_until"] = 0.0
        r["auto_turn_force"] = False
        r["auto_stop_until"] = 0.0
        r["hug_seen_ts"] = 0.0
        r["hug_open_since"] = 0.0
        r["hist"] = {}
        r["lastv"] = {}
        r["eval_rx"] = 0.0
        r["last_auto_cmd"] = b'S'

    def set_rover_mode(self, mode):
        r = self.rovers[self.selected_rover]
        r["mode"] = mode
        if mode == "AUTO":
            with self.state_lock:
                self._reset_auto_state(r)
        self._update_mode_buttons(mode)
        if mode in ("STOP", "MANUAL"):
            self.current_movement = "STOPPED"
            r["movement"] = "STOPPED"
            r["assigned_route"] = "STOPPED" if mode == "STOP" else "MANUAL"
            r["last_auto_cmd"] = b'S'
            self._send_cmd_to_rover(self.selected_rover, b'S')

    def _update_mode_buttons(self, mode):
        self._set_btn_style(self.btn_mode_auto, active=(mode == "AUTO"), bordered=True)
        self._set_btn_style(self.btn_mode_manual, active=(mode == "MANUAL"), bordered=True)
        self._set_btn_style(self.btn_mode_stop, active=(mode == "STOP"), bordered=True)

    def action_all_auto(self):
        with self.state_lock:
            for rid in (1, 2):
                self.rovers[rid]["mode"] = "AUTO"
                self._reset_auto_state(self.rovers[rid])
        self._update_mode_buttons("AUTO")

    def action_all_stop(self):
        for rid in (1, 2):
            self.rovers[rid]["mode"] = "STOP"
            self.rovers[rid]["movement"] = "STOPPED"
            self.rovers[rid]["assigned_route"] = "STOPPED"
            self.rovers[rid]["last_auto_cmd"] = b'S'
            self._send_cmd_to_rover(rid, b'S')
        self.current_movement = "STOPPED"
        self._update_mode_buttons("STOP")

    def _send_cmd_to_rover(self, rover_id, cmd_bytes):
        try:
            if rover_id == 2:
                self.cmd_socket.sendto(b'2' + cmd_bytes, (ESP_AP_IP, COMMAND_PORT))
                r2_ip = self.rovers[2]["ip"]
                if r2_ip and r2_ip != ESP_AP_IP:
                    self.cmd_socket.sendto(cmd_bytes, (r2_ip, COMMAND_PORT))
            else:
                r1_ip = self.rovers[1]["ip"] or ESP_AP_IP
                self.cmd_socket.sendto(cmd_bytes, (ESP_AP_IP, COMMAND_PORT))
                if r1_ip != ESP_AP_IP:
                    self.cmd_socket.sendto(cmd_bytes, (r1_ip, COMMAND_PORT))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Autonomous driving
    # ------------------------------------------------------------------
    def _effective_range(self, r, key, raw, now, new_sample):
        """Filtered, conservative range. Returns -1.0 only when path is genuinely open/unknown-far."""
        hist = r.setdefault("hist", {}).setdefault(key, [])
        lastv = r.setdefault("lastv", {})
        if new_sample:
            hist.append(raw)
            del hist[:-AUTO_FILTER_N]
            if 0 < raw <= MAX_SONAR_CM:
                lastv[key] = (raw, now)

        valid = [v for v in hist if 0 < v <= MAX_SONAR_CM]
        newest = hist[-1] if hist else -1.0
        if 0 < newest <= MAX_SONAR_CM:
            return min(valid)  # closest of last N readings

        # Newest reading invalid (0 / -1 / out of range)
        lv = lastv.get(key)
        if lv and (now - lv[1]) <= AUTO_NOECHO_MEMORY_S and lv[0] <= AUTO_NOECHO_NEAR_CM:
            return lv[0]  # lost echo right after a close object -> assume blocked
        return -1.0

    def _auto_send(self, rid, r, cmd, now):
        if cmd != r["last_auto_cmd"] or (now - r["last_auto_send"]) >= AUTO_CMD_INTERVAL_S:
            self._send_cmd_to_rover(rid, cmd)
            r["last_auto_cmd"] = cmd
            r["last_auto_send"] = now

    def _evaluate_and_run_auto(self, rid, r, now):
        d = r["data"]

        # 1. No data or stale data -> stop. Never drive blind.
        if r["last_rx"] <= 0 or (now - r["last_rx"]) > AUTO_DATA_STALE_S:
            r["movement"] = "STOPPED"
            r["assigned_route"] = "WAIT SIGNAL"
            r["auto_turn_until"] = 0.0
            r["auto_turn_force"] = False
            self._auto_send(rid, r, b'S', now)
            if rid == self.selected_rover:
                self.current_movement = "STOPPED"
            return

        # 2. Filtered ranges (history updated only once per new packet)
        new_sample = r.get("eval_rx") != r["last_rx"]
        r["eval_rx"] = r["last_rx"]
        d_front = self._effective_range(r, "d1", float(d.get("d1", -1)), now, new_sample)
        d_left  = self._effective_range(r, "d2", float(d.get("d2", -1)), now, new_sample)
        d_right = self._effective_range(r, "d3", float(d.get("d3", -1)), now, new_sample)

        front_open = (d_front <= 0) or (d_front > AUTO_FRONT_BLOCK_CM)
        front_clear_for_turn_exit = (d_front <= 0) or (d_front > AUTO_FRONT_BLOCK_CM + AUTO_CLEAR_HYSTERESIS)
        left_open  = (d_left <= 0)  or (d_left > AUTO_SIDE_BLOCK_CM)
        right_open = (d_right <= 0) or (d_right > AUTO_SIDE_BLOCK_CM)
        emergency  = 0 < d_front < AUTO_FRONT_STOP_CM

        possible = [k for k, ok in (("F", front_open), ("L", left_open), ("R", right_open)) if ok]
        r["possible_routes"] = possible if possible else ["PIVOT"]

        # Wall-hugging side setup (R1 = RIGHT-hand rule, R2 = LEFT-hand rule)
        if r["preference"] == "LEFT":
            hug_cmd, hug_move, hug_name = b'L', "TURNING LEFT", "LEFT"
            hug_open, hug_d = left_open, d_left
            away_cmd, away_move, away_name = b'R', "TURNING RIGHT", "RIGHT"
            away_open = right_open
        else:
            hug_cmd, hug_move, hug_name = b'R', "TURNING RIGHT", "RIGHT"
            hug_open, hug_d = right_open, d_right
            away_cmd, away_move, away_name = b'L', "TURNING LEFT", "LEFT"
            away_open = left_open

        hug_has_wall = 0 < hug_d <= AUTO_HUG_OPEN_CM
        if hug_has_wall:
            r["hug_seen_ts"] = now
            r["hug_open_since"] = 0.0
        wall_recent = (now - r["hug_seen_ts"]) <= AUTO_HUG_MEMORY_S and r["hug_seen_ts"] > 0

        # 3. Blocked while driving forward -> full stop first
        if not front_open and r["last_auto_cmd"] == b'F' and now >= r["auto_turn_until"]:
            r["auto_stop_until"] = now + AUTO_STOP_PAUSE_S

        if now < r.get("auto_stop_until", 0.0):
            cmd, move, route_label = b'S', "STOPPED", "OBSTACLE STOP"

        # 4. Committed turn in progress. Normal turns abort once front is clearly open;
        #    corner turns into an opening are forced to complete.
        elif now < r["auto_turn_until"] and (r["auto_turn_force"] or not front_clear_for_turn_exit):
            cmd, move, route_label = r["auto_turn_cmd"], r["auto_turn_move"], r["auto_turn_label"]

        # 5. Wall-hugging decision
        else:
            if not front_open:
                # Front blocked: wall-follow priority = hugged side, then away side, else pivot
                r["hug_open_since"] = 0.0
                if hug_open and wall_recent:
                    cmd, move, route_label = hug_cmd, hug_move, f"{hug_name} [HUG]"
                elif away_open:
                    cmd, move, route_label = away_cmd, away_move, f"{away_name} [FIND WALL]"
                elif hug_open:
                    cmd, move, route_label = hug_cmd, hug_move, f"{hug_name} [ALT]"
                else:
                    cmd, move, route_label = away_cmd, away_move, f"PIVOT {away_name}"
                r["auto_turn_until"] = now + AUTO_TURN_HOLD_S
                r["auto_turn_cmd"] = cmd
                r["auto_turn_move"] = move
                r["auto_turn_label"] = route_label
                r["auto_turn_force"] = False
            else:
                # Front open
                if 0 < hug_d < AUTO_SIDE_TOO_CLOSE_CM and away_open:
                    cmd, move, route_label = away_cmd, away_move, f"WALL TOO CLOSE -> {away_name}"
                elif (not hug_has_wall) and wall_recent:
                    # Wall just disappeared: advance past the corner, then turn into the opening
                    if r["hug_open_since"] == 0.0:
                        r["hug_open_since"] = now
                    if (now - r["hug_open_since"]) >= AUTO_HUG_ADVANCE_S:
                        cmd, move, route_label = hug_cmd, hug_move, f"{hug_name} [CORNER]"
                        r["auto_turn_until"] = now + AUTO_HUG_CORNER_TURN_S
                        r["auto_turn_cmd"] = cmd
                        r["auto_turn_move"] = move
                        r["auto_turn_label"] = route_label
                        r["auto_turn_force"] = True
                        r["hug_open_since"] = 0.0
                        r["hug_seen_ts"] = 0.0
                    else:
                        cmd, move, route_label = b'F', "FORWARD", "ADVANCE TO CORNER"
                elif hug_has_wall and hug_d > AUTO_HUG_FAR_CM and hug_open:
                    cmd, move, route_label = hug_cmd, hug_move, f"WALL FAR -> {hug_name}"
                elif not hug_has_wall:
                    cmd, move, route_label = b'F', "FORWARD", "SEEK WALL"
                else:
                    cmd, move, route_label = b'F', "FORWARD", f"HUG {hug_name}"

        # 6. Last-line guard: never send F inside the hard-stop distance
        if emergency and cmd == b'F':
            cmd, move, route_label = b'S', "STOPPED", "EMERGENCY STOP"

        r["movement"] = move
        r["assigned_route"] = route_label
        if rid == self.selected_rover:
            self.current_movement = move
        self._auto_send(rid, r, cmd, now)

    # ------------------------------------------------------------------

    def set_view_mode(self, mode):
        self.view_mode = mode
        self._set_btn_style(self.btn_view_map, active=(mode == "MAP"), bordered=False)
        self._set_btn_style(self.btn_view_cam, active=(mode == "CAMERA"), bordered=False)
        if mode == "MAP":
            self.map_title_lbl.configure(text="MAP // SHARED DUAL-ROVER ULTRASONIC SLAM")
        else:
            self.map_title_lbl.configure(text=f"CAMERA // LIVE STREAM CAM {self.active_cam}")

    def select_camera(self, cam_idx):
        if self.active_cam != cam_idx:
            self.latest_cam_image = None
        self.active_cam = cam_idx
        self._set_btn_style(self.btn_cam1, active=(cam_idx == 1), bordered=False)
        self._set_btn_style(self.btn_cam2, active=(cam_idx == 2), bordered=False)
        if self.view_mode == "CAMERA":
            self.map_title_lbl.configure(text=f"CAMERA // LIVE STREAM CAM {self.active_cam}")

    def action_clear_map(self):
        with self.state_lock:
            self.obstacle_grid.clear()
            self.beam_history.clear()
            self.explored_cells.clear()
            self.map_events.clear()
            for rid in (1, 2):
                r = self.rovers[rid]
                r["trail"] = [(r["x"], r["y"])]

    def action_reset_pose(self):
        with self.state_lock:
            self.rovers[1]["x"] = 0.0
            self.rovers[1]["y"] = 0.0
            self.rovers[1]["heading"] = 0.0
            self.rovers[1]["trail"] = [(0.0, 0.0)]

            self.rovers[2]["x"] = 0.0
            self.rovers[2]["y"] = -40.0
            self.rovers[2]["heading"] = 0.0
            self.rovers[2]["trail"] = [(0.0, -40.0)]

            self.pan_offset_x = 0.0
            self.pan_offset_y = 0.0

    def action_save_map(self):
        try:
            out_dir = os.path.dirname(os.path.abspath(__file__))
            ts = int(time.time())
            json_path = os.path.join(out_dir, f"trace_slam_map_{ts}.json")
            with self.state_lock:
                export_payload = {
                    "timestamp": ts,
                    "explored_m2": round(len(self.explored_cells) * (GRID_RES_CM / 100.0) ** 2, 2),
                    "rovers": {
                        rid: {
                            "x_cm": round(r["x"], 1),
                            "y_cm": round(r["y"], 1),
                            "heading_deg": round(r["heading"], 1),
                            "trail": [(round(px, 1), round(py, 1)) for px, py in r["trail"][-500:]],
                        }
                        for rid, r in self.rovers.items()
                    },
                    "obstacles": [
                        {
                            "x_cm": round(gx * GRID_RES_CM, 1),
                            "y_cm": round(gy * GRID_RES_CM, 1),
                            "confidence": round(info["conf"], 2),
                            "type": "wall" if info.get("wall", False) else "temporary",
                            "rover": info["rover"],
                        }
                        for (gx, gy), info in self.obstacle_grid.items()
                    ],
                    "events": self.map_events,
                }
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(export_payload, f, indent=2)

            self.btn_save_map.configure(text="SAVED ✓", bg=ACCENT_ORANGE)
            self.after(1200, lambda: self.btn_save_map.configure(text="SAVE MAP", bg="#0F0F0F"))
        except Exception:
            pass

    def action_add_event(self):
        raw = self.entry_event.get().strip()
        if not raw or raw == self.event_placeholder:
            raw = f"MARKER R{self.selected_rover}"

        r = self.rovers[self.selected_rover]
        evt = {
            "name": raw,
            "rover": self.selected_rover,
            "x": round(r["x"], 1),
            "y": round(r["y"], 1),
            "heading": round(r["heading"], 1),
            "data": dict(r["data"]),
            "ts": time.strftime("%H:%M:%S"),
        }
        with self.state_lock:
            self.map_events.append(evt)

        try:
            log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trace_events_firebase.json")
            existing = []
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            existing.append(evt)
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(existing, f, indent=2)
        except Exception:
            pass

        self.entry_event.delete(0, "end")
        self.focus_set()
        self.btn_add_firebase.configure(text="LOGGED ✓", bg=ACCENT_ORANGE)
        self.after(1000, lambda: self.btn_add_firebase.configure(text="ADD TO FIREBASE", bg="#0F0F0F"))

    def handle_key_press(self, event):
        if self.focus_get() == self.entry_event and event.keysym not in ["Up", "Down"]:
            return

        cmd = None
        state_text = ""

        if event.keysym == "Up":
            cmd = b'F'
            state_text = "FORWARD"
        elif event.keysym == "Left":
            cmd = b'L'
            state_text = "TURNING LEFT"
        elif event.keysym == "Right":
            cmd = b'R'
            state_text = "TURNING RIGHT"
        elif event.keysym == "Down":
            cmd = b'S'
            state_text = "STOPPED"

        if cmd and self.current_movement != state_text:
            self.current_movement = state_text
            self.rovers[self.selected_rover]["movement"] = state_text
            if state_text != "STOPPED":
                self.rovers[self.selected_rover]["mode"] = "MANUAL"
                self._update_mode_buttons("MANUAL")
            self.send_motor_cmd(cmd)
            self.ctrl_banner.configure(
                text=f"[ MANUAL CONTROL: Use Arrow Keys (↑ Forward | ← Left | → Right | Release Stop) ]\nState: {state_text}"
            )

    def handle_key_release(self, event):
        if event.keysym in ["Up", "Left", "Right", "Down"]:
            self.current_movement = "STOPPED"
            self.rovers[self.selected_rover]["movement"] = "STOPPED"
            self.send_motor_cmd(b'S')
            self.ctrl_banner.configure(
                text="[ MANUAL CONTROL: Use Arrow Keys (↑ Forward | ← Left | → Right | Release Stop) ]\nState: STOPPED"
            )

    def send_motor_cmd(self, cmd_bytes):
        try:
            if self.selected_rover == 2:
                self.cmd_socket.sendto(b'2' + cmd_bytes, (ESP_AP_IP, COMMAND_PORT))
                if self.rovers[2]["ip"] and self.rovers[2]["ip"] != ESP_AP_IP:
                    self.cmd_socket.sendto(cmd_bytes, (self.rovers[2]["ip"], COMMAND_PORT))
            else:
                self.cmd_socket.sendto(cmd_bytes, (ESP_AP_IP, COMMAND_PORT))
        except Exception:
            pass

    def udp_listener(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.bind(("", TELEMETRY_PORT))

        while True:
            try:
                data, addr = sock.recvfrom(2048)
                parsed = json.loads(data.decode('utf-8'))

                # Camera announcement packets: update stream URL, never treat as rover telemetry
                if parsed.get("type") == "cam" or "cam_id" in parsed:
                    cid = int(parsed.get("cam_id", 1))
                    if parsed.get("stream"):
                        self.cam_URLs[cid] = parsed["stream"]
                    continue

                now = time.time()
                self.last_packet_time = now
                self.data_store = parsed
                self.rx_total += 1

                rover_id = self._resolve_rover_id(parsed, addr[0], now)
                self._ingest_rover_telemetry(rover_id, parsed, addr[0], now)
            except Exception:
                self.rx_dropped += 1

    def _resolve_rover_id(self, parsed, sender_ip, now):
        raw_id = parsed.get("rover", parsed.get("id", None))
        if raw_id in (1, "1", "R1", "r1"):
            self.ip_to_rover[sender_ip] = 1
            return 1
        if raw_id in (2, "2", "R2", "r2"):
            if sender_ip != ESP_AP_IP:
                self.ip_to_rover[sender_ip] = 2
            return 2

        if sender_ip == ESP_AP_IP:
            self.ip_to_rover[sender_ip] = 1
            return 1
        if sender_ip.startswith("192.168.4."):
            self.ip_to_rover[sender_ip] = 2
            return 2

        if sender_ip in self.ip_to_rover:
            return self.ip_to_rover[sender_ip]

        if self.rovers[1]["ip"] is None or (now - self.rovers[1]["last_rx"] > 5.0 and self.rovers[2]["ip"] != sender_ip):
            self.ip_to_rover[sender_ip] = 1
            return 1
        self.ip_to_rover[sender_ip] = 2
        return 2

    def _ingest_rover_telemetry(self, rover_id, parsed, sender_ip, now):
        with self.state_lock:
            r = self.rovers[rover_id]
            dt = now - r["last_rx"] if r["last_rx"] > 0 else 0.05
            dt = max(0.005, min(dt, 0.25))

            payload_ip = parsed.get("ip")
            if payload_ip and isinstance(payload_ip, str) and payload_ip != "0.0.0.0":
                r["ip"] = payload_ip
            elif rover_id == 2 and sender_ip == ESP_AP_IP and r["ip"] is not None:
                pass
            else:
                r["ip"] = sender_ip
            r["last_rx"] = now
            r["data"] = parsed

            gz_raw = float(parsed.get("gz", 0))
            if r["movement"] == "STOPPED":
                if not r["gz_calibrated"]:
                    r["gz_samples"] += 1
                    alpha = 1.0 / min(r["gz_samples"], 25)
                    r["gz_bias"] = (1.0 - alpha) * r["gz_bias"] + alpha * gz_raw
                    if r["gz_samples"] >= 15:
                        r["gz_calibrated"] = True
                elif abs(gz_raw - r["gz_bias"]) < 350:
                    r["gz_bias"] = 0.96 * r["gz_bias"] + 0.04 * gz_raw

                omega_dps = (gz_raw - r["gz_bias"]) / 131.0
                if abs(omega_dps) > 14.0:
                    r["heading"] = (r["heading"] + omega_dps * dt) % 360.0

            d_front = float(parsed.get("d1", parsed.get("df", -1)))
            d_left  = float(parsed.get("d2", parsed.get("dl", -1)))
            d_right = float(parsed.get("d3", parsed.get("dr", -1)))
            parsed["d1"] = d_front
            parsed["d2"] = d_left
            parsed["d3"] = d_right

            self._map_ultrasonic_beam(rover_id, r["x"], r["y"], r["heading"], d_front, now)
            self._map_ultrasonic_beam(rover_id, r["x"], r["y"], r["heading"] + 90.0, d_left, now)
            self._map_ultrasonic_beam(rover_id, r["x"], r["y"], r["heading"] - 90.0, d_right, now)

    def _map_ultrasonic_beam(self, rover_id, rx, ry, beam_angle_deg, dist_cm, now):
        if not math.isfinite(dist_cm):
            return
        angle = math.radians(beam_angle_deg)
        ux, uy = math.cos(angle), math.sin(angle)
        self.explored_cells.add((round(rx / GRID_RES_CM), round(ry / GRID_RES_CM)))
        valid = 2.0 <= dist_cm <= MAX_SONAR_CM
        if not valid:
            return
        free_limit = max(0.0, dist_cm - 1.5 * GRID_RES_CM)
        visited = set()
        d = GRID_RES_CM
        while d < free_limit:
            key = (round((rx + d * ux) / GRID_RES_CM),
                   round((ry + d * uy) / GRID_RES_CM))
            if key not in visited:
                visited.add(key)
                self.explored_cells.add(key)
                cell = self.obstacle_grid.get(key)
                if cell is not None:
                    cell["misses"] = cell.get("misses", 0) + 1
                    cell["hits"] = max(0, cell.get("hits", 0) - 1)
                    threshold = 5 if cell.get("wall", False) else 2
                    if cell["misses"] >= threshold:
                        del self.obstacle_grid[key]
            d += GRID_RES_CM * 0.8

        ox, oy = rx + dist_cm * ux, ry + dist_cm * uy
        key = (round(ox / GRID_RES_CM), round(oy / GRID_RES_CM))
        self.explored_cells.add(key)
        cell = self.obstacle_grid.get(key)
        if cell is None:
            cell = {"conf": 0.4, "rover": rover_id, "dist": dist_cm,
                    "ts": now, "hits": 0, "misses": 0, "wall": False,
                    "first_ts": now, "last_hit": 0.0}
            self.obstacle_grid[key] = cell
        if now - cell.get("last_hit", 0) >= 0.12:
            cell["hits"] += 1
            cell["last_hit"] = now
        cell["misses"] = 0
        cell["conf"] = min(3.0, cell["hits"] * 0.4)
        cell["rover"] = rover_id
        cell["dist"] = dist_cm
        cell["ts"] = now
        if cell["hits"] >= 5 and now - cell["first_ts"] >= 0.55:
            cell["wall"] = True

    def _add_obstacle_cell(self, gx, gy, rover_id, dist_cm, now, weight=0.5):
        key = (gx, gy)
        cell = self.obstacle_grid.get(key)
        if cell is None:
            self.obstacle_grid[key] = {"conf": weight, "rover": rover_id,
                "dist": dist_cm, "ts": now, "hits": 1, "misses": 0,
                "wall": False, "first_ts": now, "last_hit": now}
        else:
            if now - cell.get("last_hit", 0) >= 0.12:
                cell["hits"] = cell.get("hits", 0) + 1
                cell["last_hit"] = now
            cell["ts"] = now
            cell["misses"] = 0

    def ui_slam_tick(self):
        now = time.time()
        dt = now - self.last_odom_time
        self.last_odom_time = now
        dt = max(0.01, min(dt, 0.15))

        with self.state_lock:
            for rid, r in self.rovers.items():
                if r["mode"] == "AUTO":
                    self._evaluate_and_run_auto(rid, r, now)

                mov = r["movement"]
                d = r["data"]
                gz_raw = float(d.get("gz", 0))
                omega_imu = abs((gz_raw - r["gz_bias"]) / 131.0) if r["gz_calibrated"] else 0.0

                if mov == "TURNING LEFT":
                    turn_rate = TURN_RATE_DPS
                    if omega_imu > 8.0 and (now - r["last_rx"] < 1.0):
                        turn_rate = max(30.0, min(110.0, 0.5 * TURN_RATE_DPS + 0.5 * omega_imu))
                    r["heading"] = (r["heading"] + turn_rate * dt) % 360.0
                elif mov == "TURNING RIGHT":
                    turn_rate = TURN_RATE_DPS
                    if omega_imu > 8.0 and (now - r["last_rx"] < 1.0):
                        turn_rate = max(30.0, min(110.0, 0.5 * TURN_RATE_DPS + 0.5 * omega_imu))
                    r["heading"] = (r["heading"] - turn_rate * dt) % 360.0
                elif mov == "FORWARD":
                    d_front = float(d.get("d1", -1))
                    speed = FORWARD_SPEED_CMS
                    if 0 < d_front < 10.0:
                        speed = 0.0
                    elif 10.0 <= d_front < 20.0:
                        speed = FORWARD_SPEED_CMS * 0.45

                    rad = math.radians(r["heading"])
                    r["x"] += speed * math.cos(rad) * dt
                    r["y"] += speed * math.sin(rad) * dt

                    gx = int(round(r["x"] / GRID_RES_CM))
                    gy = int(round(r["y"] / GRID_RES_CM))
                    self.explored_cells.add((gx, gy))

                    last_x, last_y = r["trail"][-1]
                    if math.hypot(r["x"] - last_x, r["y"] - last_y) >= 3.0:
                        r["trail"].append((r["x"], r["y"]))
                        if len(r["trail"]) > 600:
                            r["trail"] = r["trail"][-600:]

        self.update_telemetry_ui()
        if self.view_mode == "MAP":
            self.render_slam_map()
        else:
            self.render_camera_view()

        self.after(60, self.ui_slam_tick)

    def update_telemetry_ui(self):
        now = time.time()
        r = self.rovers[self.selected_rover]
        r_online = (now - r["last_rx"]) < 2.0
        d = r["data"] if r["data"] else {}

        if r_online or d:
            temp = d.get("temp", 0.0)
            hum = d.get("hum", 0.0)
            mq2 = int(d.get("mq2", 0))
            self.lbl_temp_val.configure(text=f"{temp:.1f} °C" if isinstance(temp, (int, float)) else f"{temp} °C")
            self.lbl_hum_val.configure(text=f"{hum:.0f} %" if isinstance(hum, (int, float)) else f"{hum} %")
            self.lbl_mq2_val.configure(text=f"{mq2}")

            fill_w = max(3, min(96, int((mq2 / 4095.0) * 96)))
            bar_color = ACCENT_RED if mq2 >= 1800 else ACCENT_ORANGE
            self.mq2_bar_canvas.coords(self.mq2_bar_fill, 0, 0, fill_w, 6)
            self.mq2_bar_canvas.itemconfig(self.mq2_bar_fill, fill=bar_color)

            if mq2 >= 1800:
                self.lbl_env_state.configure(text="HAZARD!", fg=TEXT_WHITE, bg=ACCENT_RED)
                self.env_status_box.configure(bg=ACCENT_RED)
            else:
                self.lbl_env_state.configure(text="NOMINAL", fg=ACCENT_GREEN, bg=CARD_BG)
                self.env_status_box.configure(bg=CARD_BG)
        else:
            self.lbl_temp_val.configure(text="-- °C")
            self.lbl_hum_val.configure(text="-- %")
            self.lbl_mq2_val.configure(text="--")
            self.mq2_bar_canvas.coords(self.mq2_bar_fill, 0, 0, 3, 6)
            self.lbl_env_state.configure(text="NO DATA", fg=TEXT_MUTED, bg=CARD_BG)
            self.env_status_box.configure(bg=CARD_BG)

        d1_val = float(d.get("d1", -1)) if (r_online or d) else -1.0
        d2_val = float(d.get("d2", -1)) if (r_online or d) else -1.0
        d3_val = float(d.get("d3", -1)) if (r_online or d) else -1.0

        self.lbl_sonar_front.configure(
            text=f"{d1_val:.1f} cm" if d1_val > 0 else ("CLEAR" if r_online else "--"),
            fg=(ACCENT_RED if 0 < d1_val < 22 else (ACCENT_ORANGE if 0 < d1_val < 55 else TEXT_WHITE))
        )
        self.lbl_sonar_left.configure(
            text=f"{d2_val:.1f} cm" if d2_val > 0 else ("CLEAR" if r_online else "--"),
            fg=(ACCENT_RED if 0 < d2_val < 22 else (ACCENT_ORANGE if 0 < d2_val < 55 else TEXT_WHITE))
        )
        self.lbl_sonar_right.configure(
            text=f"{d3_val:.1f} cm" if d3_val > 0 else ("CLEAR" if r_online else "--"),
            fg=(ACCENT_RED if 0 < d3_val < 22 else (ACCENT_ORANGE if 0 < d3_val < 55 else TEXT_WHITE))
        )

        alerts = []
        if 0 < d1_val < 35:
            alerts.append(f"FRONT {d1_val:.0f}cm")
        if 0 < d2_val < 35:
            alerts.append(f"LEFT {d2_val:.0f}cm")
        if 0 < d3_val < 35:
            alerts.append(f"RIGHT {d3_val:.0f}cm")

        if alerts:
            self.lbl_range_status.configure(text="OBSTACLE: " + " | ".join(alerts), fg=ACCENT_ORANGE)
        else:
            self.lbl_range_status.configure(text="RANGE CLEAR", fg=TEXT_MUTED)

        self._draw_proximity_mini_grid(d_front=d1_val, d_left=d2_val, d_right=d3_val)

        for axis in ("AX", "AY", "AZ", "GX", "GY", "GZ"):
            bar_c, fill_id, val_lbl = self.imu_widgets[axis]
            key = axis.lower()
            if r_online or key in d:
                raw_val = float(d.get(key, 0))
                if axis == "AZ":
                    val = raw_val / 16400.0
                    val_lbl.configure(text=f"{val:.2f}")
                    norm = max(-1.0, min(1.0, val / 2.0))
                elif axis in ("GX", "GY", "GZ"):
                    val = raw_val / 131.0
                    val_lbl.configure(text=f"{val:.1f}")
                    norm = max(-1.0, min(1.0, val / 250.0))
                else:
                    val = int(raw_val)
                    val_lbl.configure(text=f"{val}")
                    norm = max(-1.0, min(1.0, raw_val / 20000.0))
                w = int(68 + norm * 64)
                bar_c.coords(fill_id, 0, 0, max(4, w), 7)
            else:
                val_lbl.configure(text="--")
                bar_c.coords(fill_id, 0, 0, 68, 7)

        r1 = self.rovers[1]
        r2 = self.rovers[2]
        r1_on = (now - r1["last_rx"]) < 2.0
        r2_on = (now - r2["last_rx"]) < 2.0

        def _fmt_rover_status(rv, on_flag):
            if rv["mode"] == "AUTO":
                open_str = ",".join(rv["possible_routes"])
                return f"AUTO:{rv['assigned_route']} ({open_str})"
            if on_flag:
                return f"ON/{rv['movement']}"
            if rv["movement"] != "STOPPED":
                return f"MAN/{rv['movement']}"
            return "OFF/--"

        r1_state = _fmt_rover_status(r1, r1_on)
        r2_state = _fmt_rover_status(r2, r2_on)
        self.lbl_fleet_state.configure(text=f"R1[R]: {r1_state}  //  R2[L]: {r2_state}")

        r1_hdg = int(round(r1["heading"])) % 360
        r2_hdg = int(round(r2["heading"])) % 360
        self.lbl_fleet_pose.configure(
            text=f"R1({int(round(r1['x']))},{int(round(r1['y']))},{r1_hdg}°)   "
                 f"R2({int(round(r2['x']))},{int(round(r2['y']))},{r2_hdg}°)"
        )

        explored_m2 = len(self.explored_cells) * ((GRID_RES_CM / 100.0) ** 2)
        obs_count = len(self.obstacle_grid)
        self.lbl_map_footer.configure(
            text=f"SHARED MAP // EXPLORED {explored_m2:.1f} m² // OBSTACLES {obs_count} // R1(R) & R2(L)"
        )

        self.lbl_bottom_status.configure(
            text=f"UDP :{TELEMETRY_PORT}  //  AP IP: {ESP_AP_IP}  //  SELECTED: ROVER {self.selected_rover}  "
                 f"//  RX TOTAL {self.rx_total}  //  DROPPED {self.rx_dropped}"
        )

    def _world_to_screen(self, wx_cm, wy_cm, cw, ch):
        sx = (cw * 0.5) + self.pan_offset_x + (wx_cm * self.px_per_cm)
        sy = (ch * 0.5) + self.pan_offset_y - (wy_cm * self.px_per_cm)
        return sx, sy

    def render_slam_map(self):
        c = self.map_canvas
        c.delete("all")
        cw, ch = c.winfo_width(), c.winfo_height()
        if cw < 40 or ch < 40:
            return
        c.configure(bg="#000000")
        scale = self.px_per_cm
        ox, oy = self._world_to_screen(0, 0, cw, ch)
        step = max(12, 32 * scale)
        for i in range(int((cw / step) + 2)):
            x = (ox % step) + i * step
            c.create_line(x, 0, x, ch, fill="#202020", width=1)
        for i in range(int((ch / step) + 2)):
            y = (oy % step) + i * step
            c.create_line(0, y, cw, y, fill="#202020", width=1)
        with self.state_lock:
            obstacles = [(key, dict(v)) for key, v in self.obstacle_grid.items()]
            rovers = {rid: {"x": r["x"], "y": r["y"],
                "heading": r["heading"], "data": dict(r["data"]),
                "last_rx": r["last_rx"]} for rid, r in self.rovers.items()}
            events = list(self.map_events)
        now = time.time()
        wall_size = max(5, GRID_RES_CM * scale * 0.95)
        for (gx, gy), info in obstacles:
            sx, sy = self._world_to_screen(gx * GRID_RES_CM, gy * GRID_RES_CM, cw, ch)
            if not (-20 < sx < cw + 20 and -20 < sy < ch + 20):
                continue
            if info.get("wall", False):
                h = wall_size / 2
                c.create_rectangle(sx-h, sy-h, sx+h, sy+h,
                                   fill=ACCENT_ORANGE, outline=ACCENT_ORANGE)
            else:
                half = max(4, GRID_RES_CM * scale * 0.48)
                c.create_rectangle(sx-half, sy-half, sx+half, sy+half,
                                   fill=ACCENT_ORANGE, outline="#FFB16A", width=1)
        for rid, r in rovers.items():
            if now - r["last_rx"] > 2.5:
                continue
            sx, sy = self._world_to_screen(r["x"], r["y"], cw, ch)
            for key, delta in (("d1", 0), ("d2", 90), ("d3", -90)):
                try:
                    distance = float(r["data"].get(key, -1))
                except (ValueError, TypeError):
                    continue
                if not 2 <= distance <= MAX_SONAR_CM:
                    continue
                a = math.radians(r["heading"] + delta)
                ex, ey = self._world_to_screen(r["x"] + distance * math.cos(a),
                                              r["y"] + distance * math.sin(a), cw, ch)
                c.create_line(sx, sy, ex, ey, fill=ACCENT_ORANGE, width=2, dash=(1, 3))
                c.create_oval(ex-4, ey-4, ex+4, ey+4, fill=ACCENT_ORANGE, outline="")
        for rid, r in rovers.items():
            sx, sy = self._world_to_screen(r["x"], r["y"], cw, ch)
            angle = math.radians(r["heading"])

            def pt(forward, side, sx=sx, sy=sy, angle=angle):
                return (sx + forward * math.cos(angle) - side * math.sin(angle),
                        sy - forward * math.sin(angle) - side * math.cos(angle))
            tip = pt(21, 0)
            left = pt(-16, 15)
            notch = pt(-7, 0)
            right = pt(-16, -15)
            c.create_polygon(*tip, *left, *notch, *right,
                             fill="#FFFFFF", outline="#AFAFAF", width=1.2)
            c.create_text(sx, sy+24, text=f"R{rid}", font=("Menlo", 9, "bold"),
                          fill="#FFFFFF" if rid == 1 else R2_COLOR)
        for evt in events:
            sx, sy = self._world_to_screen(evt["x"], evt["y"], cw, ch)
            c.create_text(sx+9, sy-9, text="! " + evt["name"],
                          anchor="w", fill=ACCENT_RED, font=("Menlo", 9, "bold"))
        c.create_text(12, 12, anchor="nw", fill="#AFAFAF",
                      font=("Menlo", 9, "bold"),
                      text="TRACE // ORANGE: CONFIRMED WALL  |  CUBE: TEMPORARY")

    def _on_map_press(self, event):
        self.focus_set()
        self._drag_start = (event.x - self.pan_offset_x, event.y - self.pan_offset_y)

    def _on_map_drag(self, event):
        if self._drag_start is not None:
            self.pan_offset_x = event.x - self._drag_start[0]
            self.pan_offset_y = event.y - self._drag_start[1]

    def _on_map_recenter(self, _event):
        self.pan_offset_x = 0.0
        self.pan_offset_y = 0.0
        self.px_per_cm = 1.45

    def _on_map_zoom(self, event):
        if getattr(event, "num", None) == 4 or getattr(event, "delta", 0) > 0:
            self.px_per_cm = min(4.5, self.px_per_cm * 1.12)
        else:
            self.px_per_cm = max(0.45, self.px_per_cm / 1.12)

    # =========================================================================
    # CAMERA STREAM VIEW (MJPEG over HTTP)
    # =========================================================================
    def camera_stream_worker(self):
        while True:
            if self.view_mode != "CAMERA" or not HAS_PIL:
                time.sleep(0.08)
                continue

            target_cam = self.active_cam
            url = self.cam_URLs.get(target_cam, "http://192.168.4.11/stream")
            try:
                self.cam_status_text = f"CONNECTING TO {url} ..."
                req = urllib.request.Request(url, headers={"User-Agent": "TRACE-FleetControl"})
                with urllib.request.urlopen(req, timeout=2.0) as stream:
                    buf = bytearray()
                    read_fn = getattr(getattr(stream, "fp", None), "read1", None)
                    while self.view_mode == "CAMERA" and self.active_cam == target_cam:
                        chunk = read_fn(4096) if read_fn else stream.read(1024)
                        if not chunk:
                            break
                        buf.extend(chunk)
                        latest_jpg = None
                        while True:
                            start = buf.find(b"\xff\xd8")
                            if start < 0:
                                if len(buf) > 32768:
                                    del buf[:-2]
                                break
                            end = buf.find(b"\xff\xd9", start + 2)
                            if end < 0:
                                if start > 0:
                                    del buf[:start]
                                if len(buf) > 512000:
                                    del buf[:]
                                break
                            latest_jpg = bytes(buf[start:end + 2])
                            del buf[:end + 2]

                        if latest_jpg is not None:
                            try:
                                img = Image.open(io.BytesIO(latest_jpg))
                                img.load()
                                self.latest_cam_image = img
                                self._cam_frame_id += 1
                                self.cam_status_text = f"LIVE // CAM {target_cam} ({url})"
                            except Exception:
                                pass
            except Exception:
                self.cam_status_text = f"NO VIDEO SIGNAL // {url} (Manual Controls Active)"
                time.sleep(0.4)

    def render_camera_view(self):
        c = self.map_canvas
        c.delete("all")
        cw = c.winfo_width()
        ch = c.winfo_height()
        if cw < 40 or ch < 40:
            return

        if HAS_PIL and self.latest_cam_image is not None:
            try:
                src = self.latest_cam_image
                cache_key = (self._cam_frame_id, cw, ch)
                if self._cam_photo_key != cache_key:
                    img_resized = src.resize((cw, ch), Image.BILINEAR)
                    self._tk_cam_photo = ImageTk.PhotoImage(img_resized)
                    self._cam_photo_key = cache_key
                c.create_image(0, 0, image=self._tk_cam_photo, anchor="nw")
            except Exception:
                pass
        else:
            c.create_text(
                cw / 2, ch / 2 - 12,
                text=f"CAM {self.active_cam} STREAM // {self.cam_URLs.get(self.active_cam)}",
                font=("Menlo", 13, "bold"),
                fill=TEXT_WHITE
            )
            c.create_text(
                cw / 2, ch / 2 + 16,
                text=self.cam_status_text,
                font=("Menlo", 10),
                fill=TEXT_MUTED
            )

        sel_r = self.rovers[self.selected_rover]
        c.create_text(
            12, 12,
            text=f"CAM {self.active_cam}  //  R{self.selected_rover} STATE: {sel_r['movement']}",
            font=("Menlo", 10, "bold"),
            fill=ACCENT_ORANGE,
            anchor="nw"
        )

    def check_connection_watchdog(self):
        now = time.time()
        r1_on = (now - self.rovers[1]["last_rx"]) < 1.8
        r2_on = (now - self.rovers[2]["last_rx"]) < 1.8

        r1_txt = "R1: ● ON" if r1_on else "R1: ○ OFF"
        r2_txt = "R2: ● ON" if r2_on else "R2: ○ OFF"
        status_str = f"{r1_txt}  |  {r2_txt}"

        if r1_on and r2_on:
            bg_col = ACCENT_GREEN
        elif r1_on or r2_on:
            bg_col = "#E67E22"
        else:
            bg_col = ACCENT_ORANGE

        self.status_card.configure(bg=bg_col)
        self.status_btn.configure(text=status_str, bg=bg_col)
        self.after(500, self.check_connection_watchdog)


if __name__ == "__main__":
    app = TraceApp()
    app.mainloop()